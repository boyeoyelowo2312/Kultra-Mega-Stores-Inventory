
# 📦 KMS SQL Analysis – Case Study 2

This project analyzes order data from Kultra Mega Stores (KMS) between 2009 and 2012 to uncover trends in sales, customer behavior, and shipping logistics. SQL-style logic was used to explore key business questions.

## 🔍 Case Scenario I – Sales & Shipping

- **Top Product Category**: Technology ($5.98M)
- **Top Regions**: West, Ontario, Prarie
- **Bottom Region**: Nunavut ($116k)
- **Appliances in Ontario**: $202,346.84
- **Bottom 10 Customers Identified**
- **Most Costly Shipping Method**: Delivery Truck ($51,971.94)

## 👥 Case Scenario II – Customer Insights

- **Top Customers by Sales**: Emily Phan, Deborah Brumfield, Roy Skaria
- **Top Small Business**: Dennis Kane ($75k)
- **Most Orders (Corporate)**: Roy Skaria (18)
- **Top Consumer Profit**: Emily Phan ($34k)
- **Shipping Analysis**: Delivery Truck used across all priorities (cost optimization needed)

## 📁 Files Included

- `KMS_SQL_Analysis_Report.xlsx`: Cleaned results and summaries
- `SQL_Queries_Used.md`: SQL-style queries used for analysis
- `README.md`: Summary and business insights

---
📊 Prepared by your data analyst assistant using Python & Pandas 💻
