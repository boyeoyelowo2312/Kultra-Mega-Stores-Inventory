
# SQL Queries Used - KMS Case Study

## Case Scenario I

1. **Highest Product Category Sales**
```sql
SELECT "Product Category", SUM(Sales)
FROM orders
GROUP BY "Product Category"
ORDER BY SUM(Sales) DESC;
```

2. **Top and Bottom Regions by Sales**
```sql
SELECT Region, SUM(Sales)
FROM orders
GROUP BY Region
ORDER BY SUM(Sales) DESC
LIMIT 3;  -- Top 3
-- Use ASC for Bottom 3
```

3. **Total Sales of Appliances in Ontario**
```sql
SELECT SUM(Sales)
FROM orders
WHERE "Product Sub-Category" = 'Appliances' AND Province = 'Ontario';
```

4. **Bottom 10 Customers by Sales**
```sql
SELECT "Customer Name", SUM(Sales)
FROM orders
GROUP BY "Customer Name"
ORDER BY SUM(Sales)
LIMIT 10;
```

5. **Shipping Cost by Shipping Method**
```sql
SELECT "Ship Mode", SUM("Shipping Cost")
FROM orders
GROUP BY "Ship Mode"
ORDER BY SUM("Shipping Cost") DESC;
```

---

## Case Scenario II

6. **Most Valuable Customers and Their Purchases**
```sql
SELECT "Customer Name", SUM(Sales)
FROM orders
GROUP BY "Customer Name"
ORDER BY SUM(Sales) DESC
LIMIT 10;
```

7. **Top Small Business Customer**
```sql
SELECT "Customer Name", SUM(Sales)
FROM orders
WHERE "Customer Segment" = 'Small Business'
GROUP BY "Customer Name"
ORDER BY SUM(Sales) DESC
LIMIT 1;
```

8. **Corporate Customer with Most Orders**
```sql
SELECT "Customer Name", COUNT(DISTINCT "Order ID")
FROM orders
WHERE "Customer Segment" = 'Corporate'
GROUP BY "Customer Name"
ORDER BY COUNT(DISTINCT "Order ID") DESC
LIMIT 1;
```

9. **Most Profitable Consumer Customer**
```sql
SELECT "Customer Name", SUM(Profit)
FROM orders
WHERE "Customer Segment" = 'Consumer'
GROUP BY "Customer Name"
ORDER BY SUM(Profit) DESC
LIMIT 1;
```

10. **Returned Items**
- No `Return` column found in dataset — cannot determine.

11. **Shipping Mode vs Order Priority**
```sql
SELECT "Order Priority", "Ship Mode", SUM("Shipping Cost")
FROM orders
WHERE "Ship Mode" IN ('Express Air', 'Delivery Truck')
GROUP BY "Order Priority", "Ship Mode";
```
